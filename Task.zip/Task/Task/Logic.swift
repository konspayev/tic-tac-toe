//
//  Logic.swift
//  Task
//
//  Created by astanahub on 20.04.2024.
//

import Foundation

final class Logic {
    var XOs: [XO] = []
    var indexUp: Int = 0
    let winCombo = [[0,1,2], [3,4,5], [6,7,8], [0,3,6], [1,4,7], [2,5,8], [0,4,8], [2,4,6]]
    
    init() {
        
    }
}
