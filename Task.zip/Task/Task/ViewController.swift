//
//  ViewController.swift
//  Task
//
//  Created by astanahub on 20.04.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    var counter = 0
    
    @IBAction func click1(_ sender: UIButton) {
        counter += 1
        if counter % 2 == 0 {
            sender.setTitle("⭕️", for: .normal)
        } else {
            sender.setTitle("❌", for: .normal)
        }
        sender.isEnabled = false
    }
    
    @IBOutlet var arrayButton: [UIButton]!
    @IBAction func restart(_ sender: UIButton) {
        for i in arrayButton {
            i.setTitle("", for: .normal)
            i.isEnabled = true
        }
        counter = 0
    }

    
}


