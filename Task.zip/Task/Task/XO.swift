//
//  XO.swift
//  Task
//
//  Created by astanahub on 20.04.2024.
//

import Foundation

struct XO {
    var XO: String?
    var isFeseUp: Bool = false
}
